#! /bin/bash

python2.7 ./source/main_q2.py $@
