#! /bin/bash

python2.7 ./source/main_q3.py $1 $2 $3 > $4
