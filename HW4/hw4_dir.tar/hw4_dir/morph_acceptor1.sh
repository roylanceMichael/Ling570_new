#! /bin/bash
python2.7 ./source/morph_acceptor_main.py $1 $2 > $3