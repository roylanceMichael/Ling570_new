#! /bin/bash
python2.7 ./source/expand_fsm_main.py $1 $2 > $3