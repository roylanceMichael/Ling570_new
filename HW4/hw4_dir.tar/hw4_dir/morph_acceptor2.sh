#! /bin/bash

python2.7 ./source/morph_acceptor_main2.py $1 $2 > $3