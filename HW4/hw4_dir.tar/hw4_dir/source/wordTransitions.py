class WordTransitions:
	def __init__(self, wordIdx, currentState, previousStates):
		self.wordIdx = wordIdx
		self.currentState = currentState
		self.previousStates = previousStates