#! /bin/bash

python2.7 acceptor.py $1 $2
