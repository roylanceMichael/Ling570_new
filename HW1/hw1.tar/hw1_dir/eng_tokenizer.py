#!/usr/bin/python

import sys
import re
import os


def tokenize(line):
  t = re.sub('(\d)([.,])(\d)', r'\1_\2_\3', line)   # decimals and big numbers
#  print t

  t = re.sub('([.\w])(\')([rsv])', r'\1 _\2\3', t)  # 're, 's, 've separated from words
  t = re.sub('(\w)([-&\'])(\w)', r'\1_\2_\3', t)  # hyphenated words, telephone numbers, names with & and other words with apostrophe
#  print t
  t = re.sub('([.\s][a-z])(\.)', r'\1_\2_', t)  # one letter-abbreviations 
#  print t
  t = re.sub('([a-z]{0,4})(\.)(\s[a-z])', r'\1_\2_\3', t)  # other abbreviations no longer than four letters 
#  print t
  t = re.sub('([A-Z][a-z]{0,3})(\.)', r'\1_\2_', t)  # some abbreviations starting with capital letters (U.S., Ph.D.); not longer than four letters
 
  t = re.sub('(\w+)(@)(\w+)(\.)(\w+)', r'\1_\2_\3_\4_\5', t)  # e-mail addresses (niceandsimple@example.com)
  t = re.sub('(\w+)(\.)(\w+)(@)(\w+)(\.)(\w+)', r'\1_\2_\3\4\5\6\7', t)  # e-mail addresses (very.common@example.com); would be nice to use + and * on groups
#  print t
  t = re.sub('(\w+)(\.)(\w+)(@)(\w+)(\.)(\w+)(\.)(\w+)', r'\1\2\3\4\5\6\7_\8_\9', t)   # very.common@dept.example.com
  t = re.sub('(\w+)(\.)(\w+)(\.)(\w+)(@)(\w+)(\.)(\w+)(\.)(\w+)', r'\1_\2_\3\4\5\6\7\8\9\10\11', t)   # even.longer.address@example.com
#  print t
 
  t = re.sub('--', '_-__-_', t)   # keep long dashes together
  t = re.sub('([\W^\s])', r' \1 ', t)   # split everything else with whitespace

  t = re.sub('\s{2,}', ' ', t)   # get rid of extra spaces
  t = re.sub('(_)*(_ )(\W)( _)', r'\3', t)   # get rid of understrikes

  return t



def main():
  line = sys.stdin.readline()
  while line:
    print tokenize(line)
    line = sys.stdin.readline()


  
if __name__ == '__main__':
  main()
