#!/bin/sh
python eng_tokenizer.py
