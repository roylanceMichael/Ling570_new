#!/usr/bin/python

import sys
import re
import os

                                   
def sort_tokens(tokcount_dict):
  tcount = tokcount_dict
  top_sort = sorted(tcount.items(), key = lambda a: -a[1]) # make into tuple and sort
  for tup in top_sort:  # slice of list
    print tup[0], '\t', tup[1]    # print element by element 



def main():
  text = sys.stdin.read()
  tokens = text.split()

  tokcount_dict = {}  # hash table - dictionary
  for word in tokens:
    if not word in tokcount_dict:
      tokcount_dict[word] = 1
    else:
      tokcount_dict[word] = tokcount_dict[word] + 1

  sort_tokens(tokcount_dict)


  
if __name__ == '__main__':
  main()
