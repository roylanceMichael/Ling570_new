#!/bin/sh
python make_voc.py
